GROK ROBOTICS PORTFOLIO QC PACKAGE

Read REVIEW_PROMPT.md first. Review portfolio-source as a read-only release candidate.
Use common/QC_CHECKLIST.csv and return the schema in common/EXPECTED_RESPONSE_SCHEMA.json.
Large MP4 binaries are excluded; MEDIA_FILE_HASHES.csv records their release-candidate hashes.
The package contains fictional scenarios and reusable templates, not production approvals.

# Research and Assumptions — Airport Restroom Humanoid Pilot

> **Evidence-confidence key:** [PB-H] public benchmark or authoritative source/high confidence; [RBE-M] range-based estimate/medium confidence; [SA-L] scenario assumption/low confidence; [DC-L] disclosed derived calculation/confidence inherits the weakest input; [UPV] unverified production value/block commitment until approved.


## Evidence hierarchy

Public sources define safety and cleaning constraints. All airport names, volumes, costs, results, and benefit inputs below are fictional scenario data unless explicitly identified as a public benchmark. Robot procurement amounts are planning allowances, not vendor quotations.

## Public sources used

**Table 1. Public sources used — Evidence: disclosed row/source notes; Confidence: see evidence key and row/source notes**

| Source | What it supports | Portfolio use |
|---|---|---|
| Centers for Disease Control and Prevention, *When and How to Clean and Disinfect a Facility*, April 16, 2024, https://www.cdc.gov/hygiene/about/when-and-how-to-clean-and-disinfect-a-facility.html | Clean high-touch surfaces regularly; clean before disinfecting; follow product directions; train and protect workers | Cleaning sequence, training, quality inspection, chemical controls |
| Centers for Disease Control and Prevention, *How to Prevent Norovirus*, January 13, 2025, https://www.cdc.gov/norovirus/prevention/index.html | Body-fluid events require immediate controlled cleanup; gloves and pathogen-appropriate disinfection | Human specialist exception path; robot does not autonomously remediate a body-fluid event |
| United States Environmental Protection Agency, *Registered Antimicrobial Products Effective Against Norovirus — List G*, current page reviewed August 2026, https://www.epa.gov/pesticide-registration/epas-registered-antimicrobial-products-effective-against-norovirus-feline | Product registration and wet contact time must match the label | Approved-chemical list, dwell-time requirement, material-compatibility test |
| Occupational Safety and Health Administration, *Hazard Communication*, 29 Code of Federal Regulations 1910.1200, https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.1200 | Labels, Safety Data Sheets, chemical information, and training | Chemical custody, storage, robot refill procedure, responder training |
| Occupational Safety and Health Administration, *Bloodborne Pathogens — Overview*, https://www.osha.gov/bloodborne-pathogens/ | Employers determine exposure and use an exposure-control plan where occupational exposure exists | Sharps and visible-blood safe stop, site exposure determination, trained human response |
| United States Bureau of Labor Statistics, national employment and wage data, May 2025, https://www.bls.gov/news.release/ocwage.t01.htm | National mean wage for janitors and cleaners was $18.64 per hour | Public wage benchmark only; the fictional $31.50 loaded airport rate is 1.69 times the wage and must be replaced with payroll or contract data |
| Metropolitan Washington Airports Authority, *Custodial Services at Ronald Reagan Washington National Airport*, solicitation 1-19-C001, https://www.mwaa.com/business/1-19-c001-custodial-services-national-airport | Public airport custodial scope runs 24 hours per day, 365 days per year and includes restrooms across approximately 1.5 million square feet; listed annual estimate was $10–11 million | Supports continuous-airport demand, not Pacific Gateway volumes or pricing |
| TRAX Analytics, *Syracuse Hancock International Airport*, https://traxinsights.com/syracuse-hancock-international-airport/ | Vendor case reports 20 restroom locations, approximately 10 minutes per restroom, and demand-based cleaning | Reasonableness check for short-visit duration; vendor-reported case, not independent benchmark |
| Agility Robotics, *GXO Signs Industry-First Multi-Year Agreement with Agility Robotics*, June 27, 2024, https://www.agilityrobotics.com/content/gxo-signs-industry-first-multi-year-agreement-with-agility-robotics | Commercial Robotics-as-a-Service deployment for tote movement in a live warehouse | Supports commercial model and dense logistics-workflow plausibility only |
| Figure, *Production at BMW*, November 2025, https://www.figure.ai/news/production-at-bmw | Vendor reports 10-hour shifts, more than 90,000 parts, 1,250 runtime hours, and contribution to more than 30,000 vehicles | Supports high-utilization manufacturing opportunity ranking; vendor-reported evidence |
| Figure, *F.03 at BMW*, https://www.figure.ai/news/f-03-at-bmw | Describes sequencing, carts, component handling, and existing production workflows | Supports human-infrastructure fit; not an airport-cost source |
| Agility Robotics, *Commercial Agreement with Toyota Motor Manufacturing Canada*, 2026, https://www.agilityrobotics.com/content/agility-robotics-announces-commercial-agreement-with-toyota-motor-manufacturing-canada | Commercial manufacturing deployment announcement | Supports opportunity ranking only |
| Agility Robotics, *Mercado Libre and Agility Robotics Announce Commercial Agreement*, https://www.agilityrobotics.com/content/mercado-libre-and-agility-robotics-announce-commercial-agreement | Vendor reports more than 100,000 totes moved using existing aisles and workflows | Supports existing-infrastructure rationale; vendor-reported evidence |
| Figure, *Agreement with Catalyst Brands*, https://www.figure.ai/news/figure-signs-agreement-with-catalyst-brands | Retail distribution commercial agreement | Supports retail opportunity ranking only |

## Fictional airport baseline

**Table 2. Fictional airport baseline — Evidence: disclosed row/source notes; Confidence: see evidence key and row/source notes**

| Input | Value | Evidence class | Owner / validation |
|---|---:|---|---|
| Pilot terminal | Terminal 4 | Scenario fact | Airport sponsor |
| Pilot restrooms | 4 | Scenario fact | Airport Facilities |
| Routine missions | 3 per restroom per day | Scenario planning input | Custodial time study |
| Pilot duration | 90 days | Approved plan | Steering committee |
| Scheduled missions | 4 × 3 × 90 = 1,080 | Derived | Project controls |
| Observed routine labor per mission | 0.50 labor-hour | Fictional pre-pilot time study | Airport Facilities; repeat before scale |
| Airport loaded labor rate | $31.50 per hour | Fictional customer input | Finance and Procurement |
| Annualized routine capacity | 4 × 3 × 365 × 0.50 = 2,190 hours | Derived | Benefits owner |
| Annualized capacity value | 2,190 × $31.50 = $68,985 | Derived, not cash savings | Finance |

The Bureau of Labor Statistics wage is a national wage benchmark, not a loaded airport cost. The scenario's $31.50 rate is 1.69 times the $18.64 May 2025 national mean wage and includes fictional benefits, shift premiums, supervision, insurance, and contractor overhead. It must be replaced with the airport's actual payroll or contract data.

## Phase 2 fictional planning inputs

**Table 3. Phase 2 fictional planning inputs — Evidence: disclosed row/source notes; Confidence: see evidence key and row/source notes**

| Input | Value | Validation required |
|---|---:|---|
| Rooms served | 12 | Approved expansion map |
| Short visits | 8 per room per day at 10 minutes | Four-week time study and passenger-demand data |
| Deep cleans | 2 per room per day at 30 minutes | Custodial work sampling |
| Productive fleet time | 28 hours per day | Dispatch simulation and proof period |
| Robots | 2 | Capacity, charging, maintenance, and resilience model |
| RaaS base price | $6,000 per robot per month | Binding competitive quotation |
| Initial integration | $150,000 | Fixed-price Statement of Work |
| Retained human support | $80,000 per year | Airport staffing and contract plan |
| Loaded task rate | $31.50 per hour | Airport Finance validation |

Robotics-as-a-Service (RaaS) converts ownership into a subscription but does not eliminate integration, retained human work, or commercial risk. The rate ceiling is a customer affordability boundary; a provider must separately approve its cost floor.

## Cost assumptions requiring quotation

**Table 4. Cost assumptions requiring quotation — Evidence: disclosed row/source notes; Confidence: see evidence key and row/source notes**

| Cost input | Base | Low | High | Status |
|---|---:|---:|---:|---|
| Two humanoid robots and chargers | $500,000 | $300,000 | $700,000 | Request for Quotation required |
| Manufacturer application engineering | $220,000 | $150,000 | $320,000 | Statement of Work required |
| Integrator configuration and commissioning | $310,000 | $220,000 | $450,000 | Statement of Work required |
| Airport site, network, cybersecurity, and entry controls | $145,000 | $100,000 | $230,000 | Site design required |
| Independent safety and acceptance | $120,000 | $80,000 | $180,000 | Test proposal required |
| Training and operational change | $70,000 | $45,000 | $110,000 | Training plan required |
| Pilot support, spares, and consumables | $110,000 | $75,000 | $180,000 | Support quote required |
| Integrated program management | $155,000 | $120,000 | $230,000 | Resource plan required |

The direct-cost base is $1,630,000. A fifteen-percent uncertainty allowance of $244,500 creates a $1,874,500 pilot authorization. This is a planning envelope, not a market-price claim.

## Claim rules

- “Mission success” means the scripted routine scope completed and a telemetry record closed; it does not prove autonomous cleaning efficacy.
- “First-pass inspection” means an authorized custodian passed all twelve checklist points at first inspection.
- “Capacity released” is time available for other assigned work. It is not headcount reduction or cash savings.
- A passed pilot is not a scale approval, product certification, infection-control guarantee, or safety certification.
- Expansion requires actual quotations, site measurements, employee consultation, airport authority approval, and an updated hazard analysis.

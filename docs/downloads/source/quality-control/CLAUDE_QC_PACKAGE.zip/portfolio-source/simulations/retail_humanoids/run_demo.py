#!/usr/bin/env python3
"""Simplified MuJoCo operations visualization for retail backroom fulfillment."""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path

import mujoco

from retail_sequence import frame_at, route_clearance_report


def mocap_id(model: mujoco.MjModel, body_name: str) -> int:
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, body_name)
    return int(model.body_mocapid[body_id])


def set_pose(data: mujoco.MjData, index: int, x: float, y: float, z: float, yaw: float = 0.0) -> None:
    data.mocap_pos[index] = (x, y, z)
    data.mocap_quat[index] = (math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2))


def run(duration: float, viewer_enabled: bool, output_dir: Path) -> None:
    model = mujoco.MjModel.from_xml_path(str(Path(__file__).with_name("retail.xml")))
    data = mujoco.MjData(model)
    robot_ids = [mocap_id(model, "robot_1"), mocap_id(model, "robot_2")]
    item_ids = [mocap_id(model, "shoe_box_1"), mocap_id(model, "shoe_box_2")]
    rows: list[dict[str, object]] = []
    start = time.monotonic()
    elapsed = 0.0
    last_sample = -1

    viewer = None
    if viewer_enabled:
        from mujoco import viewer as mujoco_viewer
        viewer = mujoco_viewer.launch_passive(model, data, show_left_ui=False, show_right_ui=False)
        camera_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "overview")
        if camera_id < 0:
            raise RuntimeError("retail.xml is missing the required 'overview' camera")
        viewer.cam.type = mujoco.mjtCamera.mjCAMERA_FIXED
        viewer.cam.fixedcamid = camera_id

    try:
        while elapsed < duration:
            frame = frame_at((elapsed % 18.0) / 18.0)
            robot_frames = [
                (frame.blue_pose, frame.blue_item_pose, frame.blue_state, frame.blue_carrying),
                (frame.green_pose, frame.green_item_pose, frame.green_state, frame.green_carrying),
            ]
            for index, (pose, item_pose, state, carrying) in enumerate(robot_frames):
                x, y, z, yaw = pose
                set_pose(data, robot_ids[index], x, y, z, yaw)
                set_pose(data, item_ids[index], *item_pose)
                sample = int(elapsed)
                if sample != last_sample:
                    rows.append({
                        "table_title": "Table 1. Retail humanoid scripted telemetry",
                        "second": sample,
                        "robot": index + 1,
                        "state": state,
                        "x_m": round(x, 2),
                        "y_m": round(y, 2),
                        "carrying": carrying,
                        "evidence_class": "Derived calculation",
                        "confidence": "Low",
                        "source_or_validation": "Deterministic scripted MuJoCo workflow; not production autonomy evidence",
                    })
            last_sample = int(elapsed)
            mujoco.mj_forward(model, data)
            if viewer:
                if not viewer.is_running():
                    break
                viewer.sync()
            if viewer:
                time.sleep(0.02)
                elapsed = time.monotonic() - start
            else:
                elapsed += 0.02
    finally:
        if viewer:
            viewer.close()

    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "retail_humanoid_telemetry.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "table_title", "second", "robot", "state", "x_m", "y_m", "carrying",
            "evidence_class", "confidence", "source_or_validation",
        ])
        writer.writeheader()
        writer.writerows(rows)
    states = sorted({str(row["state"]) for row in rows})
    required_states = {
        "blue_walk_stair_route", "blue_verify_and_pick", "blue_carry_to_employee",
        "blue_employee_handoff", "blue_inventory_confirmed",
        "green_receive_putaway_request", "green_walk_clear_receiving_aisle",
        "green_pick_receiving_carton", "green_carry_carton_to_putaway",
        "green_place_carton_on_putaway_cart", "green_putaway_complete",
    }
    clearance = route_clearance_report()
    summary = {
        "scenario": "Retail backroom humanoid fulfillment",
        "model": "retail_backroom_humanoid_fulfillment",
        "duration_seconds": duration,
        "robots": 2,
        "scope": "workflow visualization only",
        "states_demonstrated": states,
        "validation": {
            "required_states_present": required_states.issubset(states),
            "both_robots_sampled": {int(row["robot"]) for row in rows} == {1, 2},
            "blue_item_carry_observed": any(row["robot"] == 1 and row["carrying"] for row in rows),
            "green_item_carry_observed": any(row["robot"] == 2 and row["carrying"] for row in rows),
            **clearance,
            "camera_name": "overview",
            "stair_platform_height_m": 1.0,
        },
    }
    summary["passed"] = all(
        value for key, value in summary["validation"].items()
        if key not in {"camera_name", "stair_platform_height_m", "minimum_robot_center_separation_m"}
    )
    (output_dir / "retail_humanoid_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if not summary["passed"]:
        raise SystemExit("Retail workflow validation failed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--viewer", action="store_true")
    parser.add_argument("--duration", type=float, default=36.0)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()
    run(args.duration, args.viewer, args.output_dir)

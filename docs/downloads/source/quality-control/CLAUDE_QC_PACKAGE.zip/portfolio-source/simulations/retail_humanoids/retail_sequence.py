"""Order-picking half of the retail backroom MuJoCo visualization.

Both humanoids retrieve requested merchandise from different stock levels,
place it on the courtesy drop-off table, and turn back toward the shelves. A
human sales associate then reaches through the service window, collects both
packages, and closes the custody cycle. The sequence keeps robot centers
outside furniture footprints. It is an operations illustration, not a
collision-avoidance or grasping controller.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


Pose = tuple[float, float, float, float]


@dataclass(frozen=True)
class RetailFrame:
    blue_pose: Pose
    blue_item_pose: Pose
    blue_state: str
    blue_carrying: bool
    green_pose: Pose
    green_item_pose: Pose
    green_state: str
    green_carrying: bool
    human_pose: Pose
    human_left_arm_pose: Pose
    human_right_arm_pose: Pose
    human_state: str
    blue_item_visible: bool
    green_item_visible: bool
    camera: str = "overview"


def clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def smooth(value: float) -> float:
    value = clamp(value)
    return value * value * (3.0 - 2.0 * value)


def blend(a: tuple[float, ...], b: tuple[float, ...], amount: float) -> tuple[float, ...]:
    amount = smooth(amount)
    return tuple(start + (end - start) * amount for start, end in zip(a, b))


def path_pose(progress: float, points: list[tuple[float, float, float]]) -> Pose:
    progress = clamp(progress)
    scaled = progress * (len(points) - 1)
    index = min(int(scaled), len(points) - 2)
    local = scaled - index
    start, end = points[index], points[index + 1]
    x_pos, y_pos, z_pos = blend(start, end, local)
    yaw = math.atan2(end[1] - start[1], end[0] - start[0])
    return x_pos, y_pos, z_pos, yaw


def held_item(pose: Pose, height: float = 1.08) -> Pose:
    x_pos, y_pos, z_pos, yaw = pose
    return (
        x_pos + 0.42 * math.cos(yaw),
        y_pos + 0.42 * math.sin(yaw),
        z_pos + height,
        yaw,
    )


BLUE_STAIR_ROUTE = [
    (-4.20, -0.85, 0.0),
    (-4.20, -1.55, 0.0),
    (-1.00, -1.55, 0.0),
    (-0.40, -1.55, 0.20),
    (0.25, -1.55, 0.40),
    (0.82, -1.55, 0.60),
    (1.55, -1.55, 1.0),
    (2.72, -1.55, 1.0),
]
BLUE_RETURN_ROUTE = [
    *reversed(BLUE_STAIR_ROUTE),
    (-4.20, -0.85, 0.0),
    (-4.45, -0.85, 0.0),
]
GREEN_GROUND_PICK_ROUTE = [
    (-4.30, 2.15, 0.0),
    (-2.50, 1.35, 0.0),
    (0.00, 1.35, 0.0),
    (1.80, 1.75, 0.0),
    (3.15, 2.05, 0.0),
]
GREEN_DROPOFF_ROUTE = [
    (3.15, 2.05, 0.0),
    (1.50, 1.55, 0.0),
    (0.00, 1.35, 0.0),
    (-2.50, 1.35, 0.0),
    (-4.45, 0.85, 0.0),
]
GREEN_RETURN_ROUTE = [
    (-4.45, 0.85, 0.0),
    (-2.50, 1.35, 0.0),
    (-4.30, 2.15, 0.0),
]

BLUE_ITEM_HOME: Pose = (3.20, -1.55, 1.32, 0.0)
BLUE_ITEM_DROPOFF: Pose = (-5.55, -0.85, 1.19, 0.0)
GREEN_ITEM_HOME: Pose = (3.15, 2.92, 1.52, 0.0)
GREEN_ITEM_DROPOFF: Pose = (-5.55, 0.85, 1.19, 0.0)
HUMAN_HIDDEN: Pose = (-7.20, 0.0, -2.20, 0.0)
HUMAN_WINDOW: Pose = (-7.20, 0.0, 0.0, 0.0)
LEFT_ARM_HIDDEN: Pose = (-7.90, -0.55, 0.25, 0.0)
RIGHT_ARM_HIDDEN: Pose = (-7.90, 0.55, 0.25, 0.0)
LEFT_ARM_READY: Pose = (-7.85, -0.55, 1.55, 0.0)
RIGHT_ARM_READY: Pose = (-7.85, 0.55, 1.55, 0.0)
LEFT_ARM_REACH: Pose = (-7.20, -0.55, 1.55, 0.0)
RIGHT_ARM_REACH: Pose = (-7.20, 0.55, 1.55, 0.0)
LEFT_ARM_RETRACT: Pose = (-8.00, -0.55, 1.55, 0.0)
RIGHT_ARM_RETRACT: Pose = (-8.00, 0.55, 1.55, 0.0)


def turned_toward_shelves(position: tuple[float, float, float], amount: float) -> Pose:
    """Rotate from the table (pi) toward the stock shelves (zero yaw)."""
    return position + (blend((math.pi,), (0.0,), amount)[0],)


def item_at_hand(arm_pose: Pose, side: float) -> Pose:
    """Return the package pose at the modeled human hand endpoint."""
    x_pos, y_pos, z_pos, yaw = arm_pose
    forward = 1.50
    lateral = 0.30 * side
    return (
        x_pos + forward * math.cos(yaw) - lateral * math.sin(yaw),
        y_pos + forward * math.sin(yaw) + lateral * math.cos(yaw),
        z_pos - 0.30,
        yaw,
    )


def blue_sequence(progress: float) -> tuple[Pose, Pose, str, bool]:
    if progress < 0.28:
        pose = path_pose(progress / 0.28, BLUE_STAIR_ROUTE)
        return pose, BLUE_ITEM_HOME, "blue_walk_stair_route", False
    if progress < 0.35:
        pose = (2.72, -1.55, 1.0, 0.0)
        item = blend(BLUE_ITEM_HOME, held_item(pose), (progress - 0.28) / 0.07)
        return pose, item, "blue_verify_and_pick", progress >= 0.32
    if progress < 0.68:
        pose = path_pose((progress - 0.35) / 0.33, BLUE_RETURN_ROUTE)
        return pose, held_item(pose), "blue_carry_to_courtesy_table", True
    if progress < 0.75:
        pose = (-4.45, -0.85, 0.0, math.pi)
        item = blend(held_item(pose), BLUE_ITEM_DROPOFF, (progress - 0.68) / 0.07)
        return pose, item, "blue_courtesy_dropoff", progress < 0.73
    if progress < 0.83:
        pose = turned_toward_shelves((-4.35, -0.85, 0.0), (progress - 0.75) / 0.08)
        return pose, BLUE_ITEM_DROPOFF, "blue_turn_toward_shelves", False
    return (-4.35, -0.85, 0.0, 0.0), BLUE_ITEM_DROPOFF, "blue_wait_for_human_pickup", False


def green_sequence(progress: float) -> tuple[Pose, Pose, str, bool]:
    if progress < 0.06:
        return (-4.30, 2.15, 0.0, 0.0), GREEN_ITEM_HOME, "green_receive_pick_request", False
    if progress < 0.26:
        pose = path_pose((progress - 0.06) / 0.20, GREEN_GROUND_PICK_ROUTE)
        return pose, GREEN_ITEM_HOME, "green_walk_to_ground_stock", False
    if progress < 0.33:
        pose = GREEN_GROUND_PICK_ROUTE[-1] + (math.pi / 2,)
        item = blend(GREEN_ITEM_HOME, held_item(pose), (progress - 0.26) / 0.07)
        return pose, item, "green_pick_requested_carton", progress >= 0.30
    if progress < 0.66:
        pose = path_pose((progress - 0.33) / 0.33, GREEN_DROPOFF_ROUTE)
        return pose, held_item(pose), "green_carry_to_courtesy_table", True
    if progress < 0.73:
        pose = (-4.45, 0.85, 0.0, math.pi)
        item = blend(held_item(pose), GREEN_ITEM_DROPOFF, (progress - 0.66) / 0.07)
        return pose, item, "green_courtesy_dropoff", progress < 0.71
    if progress < 0.81:
        pose = turned_toward_shelves((-4.35, 0.85, 0.0), (progress - 0.73) / 0.08)
        return pose, GREEN_ITEM_DROPOFF, "green_turn_toward_shelves", False
    return (-4.35, 0.85, 0.0, 0.0), GREEN_ITEM_DROPOFF, "green_wait_for_human_pickup", False


def human_sequence(progress: float) -> tuple[Pose, Pose, Pose, str]:
    if progress < 0.76:
        return HUMAN_HIDDEN, LEFT_ARM_HIDDEN, RIGHT_ARM_HIDDEN, "human_waiting_beyond_window"
    if progress < 0.82:
        amount = (progress - 0.76) / 0.06
        return (
            blend(HUMAN_HIDDEN, HUMAN_WINDOW, amount),
            blend(LEFT_ARM_HIDDEN, LEFT_ARM_READY, amount),
            blend(RIGHT_ARM_HIDDEN, RIGHT_ARM_READY, amount),
            "human_enters_service_window",
        )
    if progress < 0.88:
        amount = (progress - 0.82) / 0.06
        return (
            HUMAN_WINDOW,
            blend(LEFT_ARM_READY, LEFT_ARM_REACH, amount),
            blend(RIGHT_ARM_READY, RIGHT_ARM_REACH, amount),
            "human_reaches_for_packages",
        )
    if progress < 0.91:
        return HUMAN_WINDOW, LEFT_ARM_REACH, RIGHT_ARM_REACH, "human_grasps_packages"
    if progress < 0.97:
        amount = (progress - 0.91) / 0.06
        return (
            HUMAN_WINDOW,
            blend(LEFT_ARM_REACH, LEFT_ARM_RETRACT, amount),
            blend(RIGHT_ARM_REACH, RIGHT_ARM_RETRACT, amount),
            "human_retracts_packages_through_window",
        )
    return HUMAN_WINDOW, LEFT_ARM_RETRACT, RIGHT_ARM_RETRACT, "human_pickup_complete"


def frame_at(progress: float) -> RetailFrame:
    progress = clamp(progress)
    blue_pose, blue_item, blue_state, blue_carrying = blue_sequence(progress)
    green_pose, green_item, green_state, green_carrying = green_sequence(progress)
    human_pose, left_arm, right_arm, human_state = human_sequence(progress)
    if progress >= 0.88:
        left_hand_item = item_at_hand(left_arm, -1.0)
        right_hand_item = item_at_hand(right_arm, 1.0)
        if progress < 0.91:
            blue_item = blend(BLUE_ITEM_DROPOFF, left_hand_item, (progress - 0.88) / 0.03)
            green_item = blend(GREEN_ITEM_DROPOFF, right_hand_item, (progress - 0.88) / 0.03)
        else:
            blue_item = left_hand_item
            green_item = right_hand_item
    items_visible = progress < 0.97
    camera = "overview"
    if 0.18 <= progress < 0.52:
        camera = "stairs"
    elif 0.52 <= progress < 0.66:
        camera = "shelves"
    elif progress >= 0.66:
        camera = "courtesy"
    return RetailFrame(
        blue_pose=blue_pose,
        blue_item_pose=blue_item,
        blue_state=blue_state,
        blue_carrying=blue_carrying,
        green_pose=green_pose,
        green_item_pose=green_item,
        green_state=green_state,
        green_carrying=green_carrying,
        human_pose=human_pose,
        human_left_arm_pose=left_arm,
        human_right_arm_pose=right_arm,
        human_state=human_state,
        blue_item_visible=items_visible,
        green_item_visible=items_visible,
        camera=camera,
    )


def route_clearance_report(samples: int = 501) -> dict[str, float | bool]:
    """Check 2-D center clearance against furniture footprints and each robot."""
    # Expanded by the humanoid's 0.23 m body half-width plus a 0.10 m visual margin.
    obstacles = {
        "courtesy_dropoff_table": (-6.63, -4.57, -1.88, 1.88),
        "ground_stock_rack": (2.14, 4.16, 2.17, 4.53),
    }
    minimum_robot_separation = float("inf")
    obstacle_clear = True
    for index in range(samples):
        frame = frame_at(index / (samples - 1))
        centers = (frame.blue_pose[:2], frame.green_pose[:2])
        minimum_robot_separation = min(
            minimum_robot_separation,
            math.dist(centers[0], centers[1]),
        )
        for x_pos, y_pos in centers:
            for x_min, x_max, y_min, y_max in obstacles.values():
                if x_min < x_pos < x_max and y_min < y_pos < y_max:
                    obstacle_clear = False
    final = frame_at(1.0)
    return {
        "furniture_clearance_passed": obstacle_clear,
        "minimum_robot_center_separation_m": round(minimum_robot_separation, 3),
        "robot_separation_passed": minimum_robot_separation >= 0.70,
        "robots_face_shelves_after_handoff": abs(final.blue_pose[3]) < 0.01 and abs(final.green_pose[3]) < 0.01,
        "human_pickup_complete": final.human_state == "human_pickup_complete",
        "packages_removed_after_human_pickup": not final.blue_item_visible and not final.green_item_visible,
    }
